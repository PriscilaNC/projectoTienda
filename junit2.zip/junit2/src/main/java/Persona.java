import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.FileWriter;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Persona {
     private String nombre;
     private int edad;
     private String rut;
     private String email;

     public Persona(String nombre, int edad, String rut, String email) {
          this.nombre = nombre;
          this.edad = edad;
          this.rut = rut;
          this.email = email;
     }
     public static Boolean validaRut ( String rut ) {
          Pattern pattern = Pattern.compile("^[0-9]+-[0-9kK]{1}$");
          Matcher matcher = pattern.matcher(rut);
          if ( matcher.matches() == false ) return false;
          String[] stringRut = rut.split("-");
          return  stringRut[1].toLowerCase().equals(CommonFn.dv(stringRut[0]));
     }
     public static void registrarPersona(Persona p){
          Gson pGson = new Gson();
          String stringJson=pGson.toJson(p);
          System.out.println("stringJson= "+ stringJson);
          p = pGson.fromJson(stringJson, Persona.class);
          System.out.println("Persona"+p);

          FileWriter writer;
          try {
               writer = new FileWriter("persona.json");
               Gson gson = new GsonBuilder().create();
               gson.toJson(p,writer);
               writer.close();
          }
          catch(
                  IOException e){
               System.out.println("No se pudo guardar el archivo");
          }}

     @Override
     public String toString() {
          return "Nombre " + nombre + '\'' +
                  ", edad: " + edad +
                  ", rut: " + rut + '\'' +
                  ", email: " + email ;
     }
}
