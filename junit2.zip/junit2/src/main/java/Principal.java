public class Principal {
    public static void main(String[] args) {
        Persona p1 = new Persona("Laura",45,"12456789-k","laura12@g.mail.com");
         p1.registrarPersona(p1);

    }
}
